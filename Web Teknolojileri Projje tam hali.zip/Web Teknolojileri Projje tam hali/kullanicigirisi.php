
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>KUBİLAY AKŞAHİN</title>
<p
	<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">

</head>

<body>

	<header>
		<h2><a href="#"></a></h2>
		<nav>
			<li><a href="index.html">Hakkında</a></li>
			<li><a href="erbaa.html" target="_blank">Şehrim</a></li>
			<li><a href="#">Mirasımız</a></li>
			<li><a href="#">Özgeçmiş</a></li>
		</nav>
	</header>

   <body> 
    
	<section class="Hakkımda">
	<?php
 
   $kadi = $_POST['kadi'];
   $sifre = $_POST['sifre'];
 
	if ($kadi=="" or $sifre=="")
	{
		echo "Lütfen Tüm Alanları Doldurun!";
		header("Refresh: 2; url=giris.html");
	}
	else
	{
		if ($kadi=="admin" && $sifre=="12345")
		{
			echo "Hoş Geldin " .$kadi." Başarılı Şekilde Giriş Yaptınız";	
		}
		else
		{
			echo "Hatalı Kullanıcı Adı veya Şifre Girdiniz. Giriş sayfasına yönlendiriliyorsunuz...";	
		
		    header("Refresh: 2; url=giris.html");
		}
	}
?>
</section>
   </body>
</html>